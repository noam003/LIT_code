from multiprocessing.pool import ThreadPool
import speech_to_text
import asr_performance
import pandas as pd
from tqdm import tqdm
'''
This file is producer multi-threading program that allows for concurrent data processing;
which in turn speeds up the process for SpeechToText and ASR_performance.
Producer is responsible of putting items into the Queue.
The tasks in queue will be placed in a ThreadPool, which is a pool of reusable threads available
to perform tasks.
The type of ThreadPool used in this script is imap_unordered because:
a. we do not care for the order of tasks being processed
b. it does not wait for the tasks to be fully compiled before processing
c. faster than map
d. works with the progress bar library tqdm:
   apply_async, imap, imap_unordered are naturally compatible with tqdm to show progress bars.
   https://leimao.github.io/blog/Python-tqdm-Multiprocessing/
'''


class MultiThreading:
    def __init__(self, asr_type: str, refData: str, lenRefData_lines: int, normalize = True):
        self.asr_type: str = asr_type
        self.refData: str = refData  # string of reference text
        self.lenRefData_lines: int = lenRefData_lines  # length of strings in reference text
        self.normalize = normalize # if true, normalize files before sending to ASR

    def run(self, paths: list[str]) -> pd.DataFrame:
        list_data_frames = []
        total_tasks = len(paths)

        with tqdm(total=total_tasks, desc="Processing") as progress_bar:
            # Create a thread pool
            with ThreadPool(processes=100) as pool:
                for result in pool.imap_unordered(self.consumer, paths):
                    list_data_frames.append(result)
                    progress_bar.update(1)  # Increment by one for each completed task

        print('ASR operation complete!')
        return pd.concat(list_data_frames, ignore_index=True)
    # ie needs loop
    def consumer(self, path: str) -> pd.DataFrame:
        normalized_files_info, _, script = speech_to_text.transcribe(
            list_filenames=[path], api=self.asr_type, normalize=self.normalize)

        return asr_performance.calculation(
            files_info=normalized_files_info, transcriptions=script,
            reference_data=self.refData, lenRef=self.lenRefData_lines)
