head_acoustics = {
    "discover": "play discover weekly",
    "beatles": "play the beatles",
    "gaga": "play shallow by lady gaga",
    "chill-beats": "play chill beats music",
    "metallica": "play metallica",
    "artists": "show me my artists",
    "playlists": "show me my playlists",
    "playlist": "show me my playlist",
    "favorites": "play my favorites",
    "elton-john": "show me elton john",
    "podcasts": "show me my podcasts",
    "harvard-1": "The birch canoe slid on the smooth planks Glue the sheet to the dark blue background It's easy to tell the depth of a well These days a chicken leg is a rare dish Rice is often served in round bowls"
}

def get_ha_command(command_name: str):
    # using for clarity in batch processing
    cmd = command_name.replace('-near', '')
    cmd = cmd.replace('-far', '')

    return head_acoustics[cmd]
