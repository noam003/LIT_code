# import houndify
# import json
# import sys
# import audiofile

# # Dependencies:
# # pip3 install houndify
# # Houndify credentials (speech-to-text only domain):
# CLIENT_ID = 'oNWHZefGfrSc5GqeXiCyuw=='
# CLIENT_KEY = 'rr_NpTIP7n4Q9FTSnfc_lMdv2sMTMA1YBhRCsRX0mWGoTKuVG62pPXO64YKOX8mgHXkRPzC1nj6Ap1WSqUbrqQ=='
# USER_ID = 'test_user'

# SAMPLING_RATE = 16000


# def input_format_check(file_path:str) -> bool:
#     '''
#     This function makes sure that the input file is in the right format.
#     '''
#     if (channels := audiofile.channels(file_path)) > 1:
#         print("Expected a mono audio file. Number of channels in input file:",
#             channels, file=sys.stderr)
#         return False

#     if (samplerate := audiofile.sampling_rate(file_path)) != 16000:
#         print("Expected a sample rate of 16k. Sample rate of input file:",
#             samplerate, file=sys.stderr)
#         return False

#     if (dur :=audiofile.duration(file_path)) > 60:
#         print("Expected a duration of less then 60 seconds. Duration of input file:",
#             dur ,file=sys.stderr)
#         return False

#     if (bit := audiofile.bit_depth(file_path)) != 16:
#         print("Expected a bit depth of 16. bit depth of input file:",
#             bit ,file=sys.stderr)
#         return False

#     return True


# class __HoundifyListener(houndify.HoundListener):
#     '''
#     HoundListener is an abstract base class that defines the callbacks
# that can be received while streaming speech to the server
#     '''

#     def onPartialTranscript(self, transcript):
#         self.PartialTranscript = transcript

#     def onFinalResponse(self, response):
#         data = response["Disambiguation"]["ChoiceData"][0]
#         print("Transcription:", data["Transcription"])
#         print("ASRConfidence:", data["ASRConfidence"])

#     def onError(self, err):
#         print("Error:", err, file=sys.stderr)


# def transcribeHoundify(speechFile: str):
#     """
#         Given an audio file containing speech, returns transciption and confidence scores.
#     Audio file must be wave file, monochannel, @ 16k Hz.
#     """
#     if input_format_check(speechFile):
#         BUFFER_SIZE = 2048
#         with open(speechFile, "rb") as audio_file:
#             client = houndify.StreamingHoundClient(
#                 CLIENT_ID, CLIENT_KEY, USER_ID, sampleRate=SAMPLING_RATE, enableVAD=False)

#             hound_listener = __HoundifyListener()
#             client.start(hound_listener)

#             # Remove wav file header so we read 44 bytes
#             audio_file.read(44)
#             while len(samples := audio_file.read(BUFFER_SIZE)) > 0:
#                 client.fill(samples)

#             client.finish()
