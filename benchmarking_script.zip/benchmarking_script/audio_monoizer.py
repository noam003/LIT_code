import argparse
import pathlib
import pydub

parser = argparse.ArgumentParser(description='Recursively make all audio files mono in a folder')
parser.add_argument('path', type=str, help='path to directory')
args = parser.parse_args()

parent = pathlib.Path(args.path)
filtered = parent.rglob("*.wav")
filepaths = [str(filepath) for filepath in filtered]

for filepath in filepaths:
    audio_seg = pydub.AudioSegment.from_wav(filepath)
    
    if audio_seg.channels > 1:
        audio_seg = audio_seg.split_to_mono()[0]
    
        byte_depth = 16 // 8
        audio_seg.set_sample_width(byte_depth).export(filepath, format='wav')