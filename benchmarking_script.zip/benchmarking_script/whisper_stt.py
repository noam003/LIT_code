"""
Here is a link to the README
https://github.com/openai/whisper/blob/main/README.md
"""
import whisper
import math


def transcribeWhisper(input_file:str):
    print("Input File:", input_file)

    model = whisper.load_model("base")

    # load audio and pad/trim it to fit 30 seconds
    audio = whisper.load_audio(input_file)
    audio = whisper.pad_or_trim(audio)

    # make log-Mel spectrogram and move to the same device as the model
    mel = whisper.log_mel_spectrogram(audio).to(model.device)

    # decode the audio
    options = whisper.DecodingOptions(language= 'en', fp16=False)
    result = whisper.decode(model, mel, options)

    # This is how they say to caluclate the confidence
    confidence = math.exp(result.avg_logprob)

    # left these two statments for debugging
    # print("-Confidence:", confidence)
    # print("-Transcript:", result.text)

    return [{
        "transcript": result.text,
        "confidence": confidence,
        }]
