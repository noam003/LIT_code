# Yobe-tools repo
This repo is dedicated to programs used for benchmarking tests. e.g. mic recording tasks

# Protocol:
1) Organize folders e.g. mic_distance/degree/Processed/SNR/______shift_.wav
2) Run tabulate_audiofiles.py by typing:
   python tabulate_audiofiles.py google reference.txt -sd mic_distance
3) Run table_visualization.py by typing:
   python table_visualization.py output.xlsx final_table.xlsx line_plot_title

# Main script: tabulate_audiofiles.py
This is the main script that calls other modules:
a) rename_files.py : goes through folders recursively and rename them to only include shift number (shift_#.wav)
b) asr_multi_threading.py : multithreading feature that processes audio files
c) writing_df from asr_performance.py : writes output from multithreading into .csv and .xlsx files

# asr_multi_threading.py
This file is producer multi-threading program that allows for concurrent data processing;
which in turn speeds up the process for speech_to_text and asr_performance.  
a) It calls speech_to_text.py for transcribing audio files. 
   This is done in speech_to_text.py by calling transcribeGoogle from google_stt.py
b) After transcribing, asr_performance does calculations using Python's JiWER package

# table_visualization.py
After obtaining calculations from running tabulate_audiofiles.py, 
this script organizes the output to give four types of tables:
1) Pivot tables that records WAR for each angle, processed vs unprocessed. 
   This table also includes an average WAR for each SNRs at the end of each row.
2) A table that summarizes the average WAR for all SNRs across all angles.
3) A summary table that only records the average WAR for all SNRs, comparing processed vs unprocessed.
4) same table as 3), but rounded to a whole number
Aside from these four types of tables, this script also gives out a line plot that is based on table 4) 