import os


def rename_wav_files(root_folder: str) -> None:
    for foldername, _, filenames in os.walk(root_folder):
        for filename in filenames:
            if filename.endswith('.wav'):
                base_name = os.path.splitext(filename)[0]  # get filename without extension
                name_array = base_name.split('_')

                shift_number = ""
                for i in range(len(name_array)):  # traverse array and finds when element is 'shift' and takes number after
                    if name_array[i] == ('shift'):
                        shift_number = name_array[i + 1]

                new_file_name = 'shift_' + shift_number + '.wav'
                old_file_path = os.path.join(foldername, filename)
                new_file_path = os.path.join(foldername, new_file_name)
                os.rename(old_file_path, new_file_path)
                print(f'Renamed file {old_file_path} to {new_file_path}')

    print("Done Renaming Files!")
