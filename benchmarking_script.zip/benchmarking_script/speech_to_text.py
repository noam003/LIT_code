import csv
# from operator import itemgetter
import os
import audiofile
# from tqdm import tqdm
import pydub
# from houndify_stt import transcribeHoundify
from google_stt import transcribeGoogle
# from command_map import get_ha_command
# from whisper_stt import transcribeWhisper


def normalization(audio: pydub.audio_segment.AudioSegment, fname: str) -> str:
    """ Function that normalizes and sets bit depth to 16
        Returns transformed file

    Parameters
    ----------
    audio (pydub.audio_segment.AudioSegment): single channel audio file
    fname (list): list of unnormalized filenames

    Returns
    -------
    str: normalized filenames that has a bit depth of 16
    """
    print("Normalizing audio file...")
    split_path = os.path.split(fname)
    normalized_filename = os.path.join(
        split_path[0], "channel1_normalized_" + split_path[1])
    byte_depth = 16 // 8
    pydub.audio_segment.effects.normalize(audio).set_sample_width(
        byte_depth).export(normalized_filename, format='wav')
    return normalized_filename


def get_info(filenames_list, args_api, args_retries, normalize=True):
    """ Function that extracts information from .wav file + separating trasnscripts per .wav file
    """
    normalized_files_info = []
    transcription = []
    script = []
    filename = filenames_list[0]
    # File information before normalization. This is printed onto the terminal

        # print('File information before normalization:'
        #       '\n\tFile name:', filename,
        #       '\n\tChannels:', audiofile.channels(filename),
        #       '\n\tSample rate:', audiofile.sampling_rate(filename),
        #       '\n\tFile duration:', audiofile.duration(filename), 'seconds',
        #       '\n\tBit depth:', audiofile.bit_depth(filename),
        #       '\n')


        
    if (normalize):
        print("Normalizing file...")
        if audiofile.bit_depth(filename) != 16:
            print('Bit depth has to be 16, converting...')
        
        # Import audio file
        wav_file = pydub.AudioSegment.from_file(filename, format="wav")

        # Extracting channel 1 data from each audio files if applicable before normalization()
        if wav_file.channels == 1:
            audio_seg = pydub.AudioSegment.from_wav(filename)
        else:
            mono_audios = wav_file.split_to_mono()
            audio_seg = mono_audios[0]
        edited_filename = normalization(audio_seg, filename)
    else:
        edited_filename = filename
    
    normalized_files_info.append(edited_filename)

        # print('Now processing...')
        # if args_api == 'houndify':
        #     transcribeHoundify(normalized_filename)
        # elif args_api == 'whisper':
        #     result = transcribeWhisper(normalized_filename)
        #     print(f'{result}')
    if args_api == 'google':
        if audiofile.duration(edited_filename) >= 60:
            print('audio file is too long, it needs to be less then 60 seconds.')
        for tries in range(1, args_retries + 1):
            try:
                transcriptions = transcribeGoogle(
                    edited_filename,
                    channels=audiofile.channels(edited_filename),
                    samplerate=audiofile.sampling_rate(edited_filename))
                transcription.append(transcriptions)
                # print('Transcribed: ', edited_filename)
                break
            except Exception as e:
                if tries == args_retries:
                    raise e
                print(f'ASR attempt {tries}/{args_retries}, retrying...')

    # Extracting transcript for each filename
    for i in transcription:
        tokens = []
        for j in i:
            script_string = j['transcript']
            token = script_string.split()
            tokens.extend(x.lower().replace("'s", "") for x in token)
        script.append(tokens)

    return normalized_files_info, transcription, script


# Execution
def transcribe(list_filenames, api, retries=2, normalize=True):
    normalized_files_info, transcription, script = get_info(
        list_filenames, api, retries, normalize)
    return normalized_files_info, transcription, script
