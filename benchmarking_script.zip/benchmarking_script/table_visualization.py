import pandas as pd
import numpy as np
import argparse
import matplotlib.pyplot as plt
'''
To run:
please specify the name of input spreadsheet, the name of output spreadsheet, and the title for line plot.
input spreadsheet = output from tabulate_audiofiles.py
output spreadsheet = outfrom from table_visualization.py
e.g.
python table_visualization.py output.xlsx final_table.xlsx my_line_plot_title

table function reads off a spreadsheet output from SpeechToText.py and change table orientation
that also includes mean calculations of WAR(%) -- Word Accuracy Rate at the last row.

A line plot will also be generated for overall table for all SNRs, processed vs unprocessed.
This is saved in .png format.

Mic recording: Each table / dataframe is sorted to look something like:
Pivot table:
                                         3          -10 -9 ... 0
4                                0    1  2
channel1_normalized_shift1.wav  15cm  45 Processed   #   # ... #
channel1_normalized_shift2.wav  15cm  45 Processed   #   # ... #
Mean                                                 #   # ... #

                                         3          -10 -9 ... 0
4                                0    1  2
channel1_normalized_shift1.wav  15cm  45 Unprocessed #   # ... #
channel1_normalized_shift2.wav  15cm  45 Unprocessed #   # ... #
Mean                                                 #   # ... #

Overall table for all SNRs:
            W.A.R.(%)
3
2           -10 -9 ... 0
Processed    #  #  ... #
Unprocessed  #  #  ... #

Overall table for each degrees:
    3           -10 -9 ... 0
1   2
0   Processed    #   # ... #
    Unprocessed  #   # ... #
45  Processed    #   # ... #
    Unprocessed  #   # ... #
'''


def table(fileName, title):
    '''
    Phone recording
    0 = degree | 1 = phone | 2 = phone position | 3 = API | 4 = filename.wav
    EndFire / BroadFire testing
    0 = mic distance | 1 = degree | 2 = Processed/Unprocessed | 3 = SNR | 4 = filename.wav
    '''
    df = pd.read_excel(fileName)
    df.groupby(['2', '3'])

    df['3'] = df['3'].str.replace('SNR_', '')  # Remove SNR_ for better sorting
    df['3'] = df['3'].astype('int')  # Cast SNR column as int from str

    df['1'] = df['1'].str.replace('-deg', '')  # Remove -deg for better sorting
    df['1'] = df['1'].astype('int')  # Cast degree column as int from str

    gb = df.groupby(['1', '2'])

    dfs = [gb.get_group(x) for x in gb.groups]

    results = []
    for i in dfs:
        res = i.pivot_table(values='W.A.R. (%)',
                            index=['4', '0', '1', '2'],
                            columns='3',
                            aggfunc=[np.mean],
                            margins=True,
                            margins_name='Mean'
                            )
        # Drop last column
        res2 = res.iloc[:, :-1]
        results.append(res2)

    # Overall table per degree
    processed_unprocessed_df = df[['1', '2', '3', 'W.A.R. (%)']]
    # Group by '1' (degrees), '2' (Processed/Unprocessed), and '3' (SNR) to calculate mean
    summary_per_degree_table = processed_unprocessed_df.groupby(['1', '2', '3']).mean()
    results.append(summary_per_degree_table.unstack())

    # Overall table for all SNRs, processed vs unprocessed
    # Filtering to include only the relevant columns
    processed_unprocessed_df = df[['2', '3', 'W.A.R. (%)']]
    # Group by '2' (Processed/Unprocessed), and '3' (SNR) to calculate mean
    summary_allSNR_table = processed_unprocessed_df.groupby(['2', '3']).mean()
    results.append(summary_allSNR_table.unstack())
    # Same table but with rounded numbers
    summary_allSNR_table_rounded = processed_unprocessed_df.groupby(['2', '3']).mean().round()
    results.append(summary_allSNR_table_rounded.unstack())

    # Plot a line graph for overall table for all SNRs, processed vs unprocessed
    # x-axis
    SNRs = df['3'].sort_values(ascending=True)
    SNRs_unique = SNRs.unique()

    # y-axis
    processed = summary_allSNR_table_rounded.loc['Processed'].to_numpy()
    unprocessed = summary_allSNR_table_rounded.loc['Unprocessed'].to_numpy()

    plt.plot(SNRs_unique, processed, color='orange', label='Processed')
    plt.plot(SNRs_unique, unprocessed, color='blue', label='Unprocessed')
    plt.legend(loc='center right')

    plt.xlabel('SNRs')
    plt.ylabel('Average W.A.R. (%)')
    plt.title(title)

    plt.grid(True)

    plt.savefig(title+'.png')

    # plt.show() # will pop out a window with line plot

    return results


# Funtion that places multiple dataframes into one single Excel sheet
def multiple_dfs(df_list, sheets, fileName, spaces):
    writer = pd.ExcelWriter(fileName, engine='xlsxwriter')
    row = 0
    for dataframe in df_list:
        dataframe.to_excel(writer, sheet_name=sheets, startrow=row, startcol=0)
        row = row + len(dataframe.index) + spaces + 3
    writer.close()


# Execution
def table_visualization() -> None:
    parser = argparse.ArgumentParser(description='Table Visualization.')
    parser.add_argument('input', type=str, help='Specify name of spreadsheet from SpeechToText.py to be processed e.g. output.xlsx')
    parser.add_argument('output', type=str, help='Specify name of spreadsheet for output of TableVisualization.py e.g. DataManipulation.xlsx')
    parser.add_argument('figure_title', type=str, help='Specify title for line plot w/o spaces e.g. 15cm_Broadside')
    args = parser.parse_args()

    input_file_path = args.input  # Name of input spreadsheet (output from SpeechToText.py)
    output_file_path = args.output  # Name of output spreadsheet (output from TableVisualization.py)

    figure_title = args.figure_title

    resList = table(input_file_path, figure_title)
    multiple_dfs(resList, 'ASR performace', output_file_path, 1)


table_visualization()
