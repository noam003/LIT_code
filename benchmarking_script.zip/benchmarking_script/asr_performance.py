import pandas as pd
from pandas import DataFrame
import platform
import jiwer
import re

'''
This script calculates:
1) three types of word error rate: deletion, substitution, and insertion
2) word accuracy rate (WAR) by doing: 100 - word error rate (WER)
3) write calculations on .csv and/or .xlsx file
'''

default_transform = jiwer.Compose([
    jiwer.RemoveMultipleSpaces(),
    jiwer.RemovePunctuation(),
    jiwer.ReduceToListOfListOfWords()
])

def create_dataframe(files_info: list, deletion: list, insertion: list,
                     substitution: list, accuracy_rate: list, transcriptions: list, reference_text: str) -> pd.DataFrame:
    """Function that creates pandas data frame

       Parameters
       ----------
       files_info(list): list of file paths
       deletion(list): list of calculation deletion errors
       insertion(list): list of calculation insertion errors
       substitution(list): list of substitution errors
       accuracy_rate(list): list of calculation of word accuracy rates
       transcriptions(list): list of transcriptions
       reference_text(str): the reference text used for comparison

       Returns
       -------
       pd.DataFrame: a data frame consisting of separated filenames as data fields
                     and measurements: (insertion, deletion, & substitution) and word accuracy rate
    """
    delimiter_regex = r"\/|\\"

    # Getting data fields
    data_fields = {}
    count = 0
    numPathTokens = len(re.split(delimiter_regex, files_info[0]))
    fields = [str(x) for x in range(numPathTokens)]

    # Splitting file names according to delimiters
    while count < numPathTokens:
        for i in files_info:
            current_field = fields[count]
            var = re.split(delimiter_regex, i)
            data_fields[current_field] = data_fields.get(current_field, []) + [var[count]]
        count += 1
    dataframe1 = pd.DataFrame(data=data_fields)

    measurements = {'Deletion error (%)': deletion,
                    'Insertion error (%)': insertion,
                    'Substitution error (%)': substitution,
                    'W.A.R. (%)': accuracy_rate}
    dataframe2 = pd.DataFrame(measurements)

    transcript = {'Transcript': transcriptions}
    dataframe3 = pd.DataFrame(transcript)

    reference = {'Reference Text': [reference_text] * len(files_info)}
    dataframe4 = pd.DataFrame(reference)

    dataframe_joined = pd.concat([dataframe1, dataframe2, dataframe3, dataframe4], axis=1)

    # Reorder the columns
    columns_order = fields + ['Deletion error (%)', 'Insertion error (%)', 'Substitution error (%)', 'W.A.R. (%)', 'Transcript', 'Reference Text']
    dataframe_joined = dataframe_joined[columns_order]

    return dataframe_joined

def write_to_file(df: pd.DataFrame, output_filename: str, duration: str) -> None:
    """Function that converts pandas data frame into an excel or a csv file

       Parameters
       --------
       df(pd.DataFrame): the concatenated data frame that is to be written into a file
       output_filename(str): the name of the output file to be written
       duration(str): the duration of the audio files
    """
    # Append the duration to the bottom of the DataFrame
    duration_row = pd.DataFrame({'0': '', '1': '', 'Deletion error (%)': '', 'Insertion error (%)': '', 
                                 'Substitution error (%)': '', 'W.A.R. (%)': '', 'Transcript': '', 
                                 'Reference Text': '', 'Duration': duration}, index=[len(df)])
    df = pd.concat([df, duration_row], ignore_index=True)

    if output_filename.endswith('.xlsx'):
        df.to_excel(output_filename, index=False)
    elif output_filename.endswith('.csv'):
        df.to_csv(output_filename, index=False)
    else:
        print('Invalid output file extension. Please use .csv or .xlsx.')

def calculation(files_info: list, transcriptions: list, reference_data: str, lenRef: int):
    word_outputs = [jiwer.process_words(reference=reference_data, hypothesis=' '.join(transcription), reference_transform=default_transform, hypothesis_transform=default_transform) for transcription in transcriptions]
    deletions = list(map(lambda word_output: (word_output.deletions / lenRef) * 100, word_outputs))
    insertions = list(map(lambda word_output: (word_output.insertions / lenRef) * 100, word_outputs))
    substitutions = list(map(lambda word_output: (word_output.substitutions / lenRef) * 100, word_outputs))
    accuracy_rates = list(map(lambda word_output: 1 - word_output.wer, word_outputs))

    alignment_txt = ''
    for idx, word_output in enumerate(word_outputs):
        alignment_txt += f'{files_info[idx]=}\n{jiwer.visualize_alignment(word_output)}\n{"-"*20}\n'

    with open("alignments.txt", "a") as alignment_file:
        alignment_file.writelines(alignment_txt)

    return create_dataframe(files_info, deletions, insertions, substitutions, accuracy_rates, transcriptions, reference_data)


def writing_df(data_frame: DataFrame):
    write_to_file(data_frame, 'excel')
    # write_to_file(data_frame, 'csv')

def parse_reference_txt(filepath: str):
    with open(filepath, "r", encoding="utf8") as file:
        txt = file.read().lower().replace("'s", "")
        num_tokens = len(txt.split())
    
    return txt, num_tokens
