import os
import pathlib
import argparse
import sys
from rename_files import rename_wav_files
from asr_performance import write_to_file, calculation
import asr_multi_threading
import asr_performance
import wave

'''
This script is the main script that calls in other modules that will rename .wav files
to the correct format, before transcribing, and calculating word accuracy rates.
This script will generate unique output files for each set of speech files
(e.g., speech1_output.csv, speech2_output.xlsx).

To run:
Please specify API and parent folder that contains .wav files
e.g.
python tabulate_audiofiles.py google -d /path/to/files/tests/ -t /path/to/files/texts/
'''

def get_wav_duration(wav_file):
    with wave.open(wav_file, 'r') as wf:
        frames = wf.getnframes()
        rate = wf.getframerate()
        duration = frames / float(rate)
        return duration

def main() -> int:
    parser = argparse.ArgumentParser(description='Transcribe wave file(s)')
    parser.add_argument('api', type=str, choices=['google', 'houndify', 'whisper'], help='specify which API to use')
    parser.add_argument('-d', action='store_true', help='if set, specifies path is a directory')
    parser.add_argument('-r', dest='retries', type=int, help='number of times to retry asr on failure', default=2)
    parser.add_argument('path', type=str, help='path to .wav file/directory')
    parser.add_argument('-t', dest='textpath', type=str, required=True, help='path to directory containing .txt files')
    parser.add_argument('-sd', action='store_true', help='Search through all directories after specified parent directory')
    parser.add_argument('-dn', '--disable-normalization', dest="normalize", action='store_false', help='If present, skip the normalization step and directly pass the audio files to ASR')

    args = parser.parse_args()

    parent_folder: str = args.path  # Name of root folder containing .wav files
    text_folder: str = args.textpath  # Name of folder containing .txt files

    # Initialize the dictionary to store .wav files under their corresponding .txt keys
    txt_wav_dict = {}

    # Create lists of .wav and .txt files based on provided arguments
    if args.d:
        wav_filenames = os.listdir(args.path)
        wav_filenames = [os.path.join(args.path, filename) for filename in wav_filenames]
        wav_filenames.sort()
        txt_filenames = os.listdir(args.textpath)
        txt_filenames = [os.path.join(args.textpath, filename) for filename in txt_filenames]

    elif args.sd:
        # Going through a file recursively to filter out all .wav and .txt files
        wav_parent = pathlib.Path(args.path)
        txt_parent = pathlib.Path(args.textpath)
        filter_wav = wav_parent.rglob("*.wav")
        filter_txt = txt_parent.rglob("*.txt")
        wav_filenames = [str(i) for i in filter_wav]
        txt_filenames = [str(j) for j in filter_txt]

    else:
        wav_filenames = [args.path]
        txt_filenames = [args.textpath]

    # Debug: Print the found filenames
    print("Found wav files:", wav_filenames)
    print("Found txt files:", txt_filenames)

    # Create the dictionary with .txt filenames as keys and empty lists as values
    txt_wav_dict = {os.path.basename(txtname): [] for txtname in txt_filenames}

    # Group .wav files under their corresponding .txt files based on the naming convention
    for wavfile in wav_filenames:
        wav_base = os.path.basename(wavfile)
        prefix = wav_base.split('_')[0]
        txtname = f"{prefix}.txt"
        if txtname in txt_wav_dict:
            txt_wav_dict[txtname].append(wavfile)

    # Filter out any normalized files
    for key in txt_wav_dict:
        txt_wav_dict[key] = list(filter(lambda filename: "normalize" not in filename, txt_wav_dict[key]))

    # Debug: Print the grouping of wav files
    print("Grouped wav files by txt:", txt_wav_dict)

    # Check if there are any .wav files to process
    all_wav_files = [wav for wav_list in txt_wav_dict.values() for wav in wav_list]
    if len(all_wav_files) == 0:
        print('WARNING: No wave files to process, check -d flag and/or .wav extension', file=sys.stderr)

    with open("alignments.txt", 'w') as file:
        file.write('')

    # Process each .txt and its corresponding .wav files
    for txtname, wav_list in txt_wav_dict.items():
        if len(wav_list) > 0:
            txt_path = os.path.join(text_folder, txtname)
            ref_txt, num_ref_tokens = asr_performance.parse_reference_txt(txt_path)
            print(f"Processing {txtname} with {len(wav_list)} .wav files")
            data_frame = asr_multi_threading.MultiThreading(
                asr_type=args.api, refData=ref_txt, lenRefData_lines=num_ref_tokens, normalize=args.normalize).run(paths=wav_list)

            # Get the duration of the first wav file (assuming all have the same duration)
            duration = get_wav_duration(wav_list[0])
            duration_str = f"Duration: {duration:.2f} seconds"

            # Generate unique output filename based on the txtname
            output_filename = f"{os.path.splitext(txtname)[0]}_output.xlsx"
            write_to_file(data_frame, output_filename, duration_str)  # Write output to unique file

    return 0

if __name__ == "__main__":
    SystemExit(main())