import argparse
from dataclasses import dataclass
from typing import List
import asr_performance
from os import path
import pathlib

def main() -> int:
    parser = argparse.ArgumentParser("Score SOCOM transcriptions and generate output data")
    parser.add_argument('path', type=str, help='path to SOCOM asr output text file or directory of text files')
    parser.add_argument('ref', type=str, help='specify name of reference file (ground truth) e.g. reference.txt')

    args = parser.parse_args()

    if path.isdir(args.path):
        parent = pathlib.Path(args.path)
        filepaths = [str(filepath) for filepath in parent.rglob("*.txt")]
    else:
        filepaths = [args.path]

    results = []
    for filepath in filepaths:
       result = parse_socom_asr(filepath) 
       results += result
    
    reference_txt, num_ref_tokens = asr_performance.parse_reference_txt(args.ref)
    
    filenames = [res.filename for res in results]
    transcriptions = [[res.transcription] for res in results]
    calculations = asr_performance.calculation(filenames, transcriptions, reference_txt, num_ref_tokens)

    asr_performance.writing_df(calculations)
    
    return 0
    
@dataclass
class Result:
    filename: str
    transcription: str
    

def parse_socom_asr(filepath: str):
    results: List[Result] = []
    with open(filepath, encoding="utf8") as file:
        lines = file.readlines()
        num_files = len(list(filter(lambda line: line.startswith("FILENAME"), lines)))
        
        for i in range(num_files):
            filename = None
            while (filename is None):
                line = lines.pop(0)
                if line.startswith("FILENAME"):
                    filename = line.split(":")[-1].strip()
            
            transcription = None
            while (transcription is None):
                line = lines.pop(0)
                if line.startswith("DISPLAY FINAL RESULT"):
                    transcription = line.split(":")[-1].strip()
            
            results.append(Result(filepath + "/" + filename, transcription)) 
    
    return results

if __name__ == "__main__":
    SystemExit(main())